module.exports = (app, io) => {
  require('./auth.routes')(app, io);
  require('./protectedRoutes/index.routes')(app, io);
};
